import requests
import os
import time
import string
import random
import requests
import sys as n
import time as mm
import webbrowser
req = requests.session()
E = '\033[1;31m'
G = '\033[1;32m'
S = '\033[1;33m'        
import requests
import time
import os
from time import sleep
import sys
import sys as n
import time as mm
E = '\033[1;31m'
G = '\033[1;32m'
S = '\033[1;33m'
q = 'M A R K O'
print(""" 

""")
def ver_n(name):   
    q = requests.get(f'http://artii.herokuapp.com/make?text={name}')
    print(E+q.text)
    try:
        ver_n(lislog[2])
    except:
        ver_n(q)
        print(" ")
        print(" ")
        sleep (5)
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
tok = input (S+"TOKEN >> ")
ID = input (G+ "ID >> ")
print (G+"checkr tek tok ")
headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36",
            "Connection": "close",
            "Host": "www.tiktok.com",
            "Accept-Encoding": "gzip, deflate",
            "Cache-Control": "max-age=0"
}
user = 'q3wert5yuiopa4sdfghjklzxcv12bnm'
while True:
  Check = str("".join(random.choice(user)for i in range(4)))
  tiklog = f'https://www.tiktok.com/@{Check}'
  rq = requests.get(tiklog, headers=headers)
  if rq.status_code == 404:	         
    print (G+Check+' >> True')
    tlg =(f'''https://api.telegram.org/bot{tok}/sendMessage?chat_id={ID}&text=𝐁𝐘 → @BBZZD  ✓\n𝐔𝐒𝐄𝐑 𝐓𝐑𝐔𝐄 : [ → { Check } ← ]\n- 𝐅𝐫𝐎𝐦 : @YYYY02 - @BBZZD ''')
            
    i = requests.post(tlg)
  elif rq.status_code == 200: 
     print(E+Check)
     if Check == '': 
    	 break
    	 webbrowser.open('https://t.me/YYYY02')